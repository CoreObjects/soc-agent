---
name: kerberoast
layer: identity
technique_ids: [T1558.003]
description: 研判 Kerberoasting(服务票据离线爆破)告警。当告警涉及"请求 Kerberos 服务票据/TGS""RC4/0x17 弱加密票据请求""带 SPN 的服务账号被大量取票""疑似离线爆破服务账号口令"时选它。关键词 Kerberoast/TGS/service ticket/SPN/RC4/0x17/4769/GetUserSPNs/Rubeus。
---
# Kerberoasting 研判(T1558.003)

**攻击本质**:任意域用户向 DC 请求某带 SPN 账号的服务票据(TGS),票据用该服务账号的 NTLM 哈希加密;攻击者离线爆破还原其明文口令。RC4(etype `0x17`)是爆破工具(Rubeus/GetUserSPNs)刻意索取的可离线破解格式——现代域几乎不该出现用户 SPN 的 RC4 票据,视为异常直到被证伪。

**触发**:Security **4769**(TGS-REQ)且 `enc_type=0x17`(RC4)且服务名非机器账号($结尾)。触发事件已在 seed 里,`(:Event{event_code:'4769'})-[:BY]->请求者Account`、`-[:REQUESTED]->服务Account/Service`、`-[:FROM]->IP`、`-[:ON_HOST]->DC`。

## 研判决策树(逐步用 run_cypher 取证)

1. **请求者是普通用户,还是服务/机器账号?(先证伪)**
   ```cypher
   MATCH (a:Alert {alert_uid:$aid})<-[:TRIGGERED]-(e:Event {event_code:'4769'})-[:BY]->(req:Account)
   RETURN req.sam, req.domain, req.type, req.privileged, e.enc_type, e.ticket_options
   ```
   服务账号常年取票、机器账号规则已排除;普通用户请 RC4 才可疑。

2. **目标 SPN 账号价值几何?**
   ```cypher
   MATCH (a:Alert {alert_uid:$aid})<-[:TRIGGERED]-(e:Event {event_code:'4769'})-[:REQUESTED]->(tgt)
   OPTIONAL MATCH (tgt)-[:MEMBER_OF]->(g:Group)
   RETURN tgt.sam, tgt.privileged, collect(g.name) AS groups
   ```
   特权服务账号(域管组等)= 高价值目标,升权。

3. **RC4 对该请求者是否历史异常?(看基线)**
   ```cypher
   MATCH (req:Account {sam:$req_sam})<-[:BY]-(ev:Event {event_code:'4769'})
   RETURN ev.enc_type AS enc, count(*) AS n ORDER BY n DESC
   ```
   该请求者一贯用 AES、突然 RC4 → 异常;一贯 RC4(老应用)→ 基线,降权。也看聚合边 `(req)-[r:REQUESTED]->(tgt) RETURN r.first_seen, r.count`(首次接触该服务?)。

4. **单票还是 SPN 扫描(扇出)?——强 TP 信号**
   ```cypher
   MATCH (req:Account {sam:$req_sam})<-[:BY]-(ev:Event {event_code:'4769'})-[:REQUESTED]->(tgt)
   WHERE ev.event_time > $t0 - 600
   RETURN count(DISTINCT tgt) AS distinct_spns
   ```
   短时(<10min)去重 SPN ≥5 = GetUserSPNs 式扫描。

5. **来源主机/会话符合该用户日常吗?**
   ```cypher
   MATCH (a:Alert {alert_uid:$aid})<-[:TRIGGERED]-(e:Event {event_code:'4769'})-[:FROM]->(ip:IPAddress)
   OPTIONAL MATCH (h:Host)-[:HAS_IP]->(ip)
   RETURN ip.ip, h.hostname, h.role
   ```

5.5. **★"跨域信任 FP"豁免判定(必查 —— 别把真 roast 误当跨域正常票)**
   recipe 的「跨域信任FP豁免判定」已给出 `req_is_machine` / `same_domain` / `req_domain` / `tgt_domain` / `req_domain_trusts`,据此判:
   - ⚠️**NetBIOS 名(`NORTH`)与 FQDN(`north.sevenkingdoms.local`)是同一个域** —— 别把两者当"两个域有信任"。`same_domain=true` 就是**同域 roast,根本不是跨域**。
   - **跨域信任的正常 RC4 只豁免【机器账号】跨域引荐票**(如 `winterfell$` 向父域请票,`req_is_machine=true` 且目标域在 `req_domain_trusts` 里)→ FP。
   - **普通用户(`req_is_machine=false`)对服务账号 SPN 请 RC4、尤其多 SPN 扇出 → 这就是 Kerberoast,跨域信任【不】豁免**,该判 true_positive。

6. **爆破是否已成功?(看横向落地)**
   ```cypher
   MATCH (tgt:Account {sam:$tgt_sam})<-[:BY]-(ev2:Event {event_code:'4624'})-[:AUTHENTICATED_TO]->(h:Host)
   WHERE ev2.event_time > $roast_time
   RETURN h.hostname, ev2.logon_type
   ```
   被 roast 的服务账号在告警后从**新主机**登录 = 爆破成功已用凭据,铁证。

## 误报/良性场景(逐条证伪)
- **跨域信任默认 RC4 —— 仅限【机器账号】引荐票**(`req_is_machine=true`,如 DC$ 向父域请票、目标域在信任列表)→ FP。⚠️**普通用户对服务 SPN 扇出取 RC4 不在此列(那是 roast=TP)**;且别把 NetBIOS 名(NORTH)当成与 FQDN(north.sevenkingdoms.local)不同的域。
- **只支持 RC4 的老应用/服务账号**(老 MSSQL/Java 等)→ 一贯 RC4 基线(第 3 步 count 高、first_seen 久)→ FP。
- **漏扫/AD 评估工具**(PingCastle/BloodHound/Nessus 凭据扫描)批量取票 → 像扫描;来源为已知扫描器主机/账号 → FP。
- **服务账号正常取票 / 用户映射网络驱动器触发单张 4769** → FP。

## 判定逻辑
- **true_positive**:**普通用户(非 `$` 机器账号)对服务账号 SPN 请 RC4 且短时扇出 ≥5 去重 SPN**(同域/跨域皆算 —— 跨域信任【不】豁免用户的扇出取票);或被 roast 账号随后从新主机登录。
- **false_positive**:**机器账号(`$` 结尾)跨域引荐票**(`req_is_machine=true` 且目标域在信任列表)/ 一贯 RC4 的老应用单票 / 已知扫描器来源。
- **suspicious(升级)**:对高价值 SPN 的 RC4、但低量无扇出、请求者无基线——证据不足,写 missing_evidence(如"无法判定 SPN 是否 high-value/是否蜜罐/是否已授权扫描器")并升级,别硬判。

## 图盲区(取不到就在 missing_evidence 里说明)
SPN 服务类别与是否 high-value(仅 privileged 布尔)、蜜罐/decoy 标记、已授权扫描器标记、离线爆破本身(只能由后续登录反推)。
